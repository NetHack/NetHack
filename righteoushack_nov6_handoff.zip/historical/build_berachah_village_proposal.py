from PIL import Image, ImageDraw, ImageFont
from collections import deque
g=[list(l) for l in open('map_berachah.txt').read().splitlines()]
H,W=len(g),len(g[0])
for y in range(1,20):
    for x in range(16,34): g[y][x]='.'
houses=[]
for hx in (18,26):
    for hy in (1,6,11,16):
        for y in range(hy,hy+4):
            for x in range(hx,hx+5):
                g[y][x]='-' if y in(hy,hy+3) else ('|' if x in(hx,hx+4) else '.')
        dx=hx if hx==26 else hx+4   # doors face the streets
        g[hy+1][dx]='+'
        g[hy+2][hx+2]='V'; houses.append((hx,hy))
for x,y in [(24,5),(17,10),(24,15),(32,8)]: g[y][x]='V'   # villagers in the lanes
g[5][73]='C'
for y,x in [(5,31),(14,31)]: g[y][x]='T'
# reachability check
walk=set('.+<>{_^@AMSvbgCV')
s=(4,17); seen={s}; q=deque([s])
while q:
    x,y=q.popleft()
    for dx in(-1,0,1):
        for dy in(-1,0,1):
            n=(x+dx,y+dy)
            if 0<=n[1]<H and 0<=n[0]<W and n not in seen and g[n[1]][n[0]] in walk:
                if dx and dy and (g[y][x]=='+' or g[n[1]][n[0]]=='+'): continue
                seen.add(n); q.append(n)
bad=[(x,y) for y in range(H) for x in range(W) if g[y][x] in walk and (x,y) not in seen]
print('unreachable:',bad)
open('map_berachah_village_proposal.txt','w').write('\n'.join(''.join(r) for r in g)+'\n')
C=22; M=60; T=90
img=Image.new('RGB',(M+W*C+20,T+H*C+M+330),'white'); d=ImageDraw.Draw(img)
F=lambda s:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf',s)
d.text((M,15),'Valley of Berachah - Proposed Layout',fill='black',font=F(30))
d.text((M,55),'PROPOSAL ONLY - not implemented. Entire level fully lit (lit=1 everywhere).',fill='#b00000',font=F(16))
col={'-':'#555','|':'#555','T':'#2e8b3a','}':'#4f8fd8','+':'#a0522d','.':'#fff6d8'}
lab={'V':('#7b3fa0','V'),'@':('#e07b00','@'),'A':('#c9a400','A'),'M':('#ffd700','M'),'S':('#0a7d7d','S'),
 'C':('#d40000','C'),'_':('#999','_'),'{':('#4f8fd8','{'),'<':('#000','<'),'>':('#000','>'),'^':('#c000c0','^'),
 'v':('#bfe3e3','v'),'b':('#bfe3e3','b'),'g':('#bfe3e3','g')}
# highlight new area
d.rectangle((M+15*C-2,T+1*C-2,M+34*C+2,T+20*C+2),fill='#efe0ff')
for y in range(H):
  for x in range(W):
    c=g[y][x]; X,Y=M+x*C,T+y*C
    if c in col: 
        f=col[c] if not(c=='.' and 15<=x<=33 and 0<y<20) else '#f3e8ff'
        d.rectangle((X,Y,X+C-1,Y+C-1),fill=f)
    else:
        bg,ch=lab[c]; d.rectangle((X,Y,X+C-1,Y+C-1),fill='#fff6d8')
        d.ellipse((X+1,Y+1,X+C-2,Y+C-2),fill=bg)
        d.text((X+5,Y+2),ch,fill='white' if c not in 'vbg' else 'black',font=F(15))
# elder on bridge
X,Y=M+43*C,T+10*C; d.ellipse((X+1,Y+1,X+C-2,Y+C-2),fill='#1f5fbf'); d.text((X+5,Y+2),'E',fill='white',font=F(15))
for x in range(0,W,5): d.text((M+x*C+3,T-18),str(x),fill='#444',font=F(12))
for y in range(H): d.text((15,T+y*C+4),str(y),fill='#444',font=F(12))
# callouts
d.rectangle((M+15*C-2,T+1*C-2,M+34*C+2,T+20*C+2),outline='#7b3fa0',width=3)
d.rectangle((M+71*C,T+3*C,M+76*C,T+8*C),outline='#d40000',width=4)
yy=T+H*C+20
legend=["NEW (purple zone, x15-33): central maze removed -> 8 villager town homes (V inside), open lanes",
"C  (73,5) NE tower, top-right room: chest with Key to the Sanctum (2nd copy; Moloch also drops one)",
"E  (43,10) Town elder (far-look: 'town elder')     M (72,10) Michael's court     _ (69,10) altar to the LORD",
"@  six children in Michael's court   A angels   V peaceful villagers   S shopkeepers",
"v verse shop (48-53,5-6)   b prophetic book shop (55-60,5-6)   g general store (48-53,14-15)",
"<  (4,17) arrival stair   > (69,15) down stair   ^ (7,3) portal spot   { fountains of living water",
"T trees   } still waters   + doors   gray walls     Field gate (41,10) + bridge (42-43,10) unchanged",
"Unchanged: west portal room, trail, arrival room, ruins, hedge ring, moat, fortress walls/doors"]
for i,l in enumerate(legend): d.text((M,yy+i*28),l,fill='black',font=F(16))
img.save('berachah_village_proposal.png'); print(img.size)
