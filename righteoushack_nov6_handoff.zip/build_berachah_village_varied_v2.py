# Draft design only. Builds the varied Berachah village (x16-33, y1-19) on map_berachah.txt.
from PIL import Image, ImageDraw, ImageFont
from collections import deque
g=[list(l) for l in open('map_berachah.txt').read().splitlines()]
H,W=len(g),len(g[0])
for y in range(1,20):
    for x in range(16,34): g[y][x]='.'
def box(x0,y0,x1,y1):
    for y in range(y0,y1+1):
        for x in range(x0,x1+1):
            g[y][x]='-' if y in(y0,y1) else ('|' if x in(x0,x1) else '.')
def put(c,*pts):
    for x,y in pts: g[y][x]=c
def fill(c,x0,y0,x1,y1):
    for y in range(y0,y1+1):
        for x in range(x0,x1+1): g[y][x]=c
B={}
# 1 Bakery: 5x4, door east, outdoor ovens
box(16,1,20,4); put('+',(20,2)); put('1',(18,2)); put('o',(22,2),(22,3)); B['Bakery']=(18,2)
# 2 Blacksmith: wide 7x4, door south, forge workyard with anvils
box(26,1,32,4); put('+',(29,4)); put('2',(28,2)); put('f',(31,2)); put('f',(27,5),(31,5)); B['Blacksmith']=(28,2)
# 3 Priest: tall 5x6 chapel house, door east, herb garden south
box(16,6,20,11); put('+',(20,8)); put('3',(18,8)); fill('h',16,12,19,13); B['Priest']=(18,8)
# 8 Player home: 6x5, door west onto green, steward + 2 chests
box(28,6,33,10); put('+',(28,8)); put('8',(30,8)); put('c',(32,7),(32,9)); B['Player home (steward)']=(30,8)
# Village green (grass marks are plain floor in game)
fill(',',22,7,26,12); put('{',(24,9))   # NOTE: '{' here = well (proposal); could be dropped
# 4 Tailor: small 4x3, door south into walled courtyard
box(30,13,33,15); put('+',(31,15)); put('4',(31,14)); fill(':',30,16,33,16); B['Tailor']=(31,14)
# 5 Farmer: 5x3 cottage, door north, vegetable beds south
box(16,15,20,17); put('+',(18,15)); put('5',(18,16)); fill('~',16,18,20,19); B['Farmer']=(18,16)
# 6 Carpenter: L-shaped home, timber yard
for x in range(22,28): g[14][x]='-'
for y in range(14,19): g[y][22]='|'
g[16][27]='|'; g[15][27]='|'
for x in range(24,28): g[16][x]='-'
for y in range(16,19): g[y][24]='|'
g[18][23]='-'; g[18][22]='-'; g[18][24]='-'
put('+',(27,15)); put('6',(25,15)); fill('=',25,18,27,19); B['Carpenter']=(25,15)
# 7 Scribe: 4x3 house, door west, reading garden with benches
box(29,17,33,19); put('+',(29,18)); put('7',(31,18)); put('r',(26,17),(27,17)); B['Scribe']=(31,18)
g[5][73]='C'
# V2 route fixes (Jon pt661u)
g[10][34]='.'                       # widen village gateway: (34,10)+(34,11)
for (ox,oy),(nx,ny) in [((57,10),(71,9)),((46,10),(46,8))]: g[oy][ox]='.'; g[ny][nx]='A'   # angels off corridor
ROUTE=[(x,10) for x in range(35,69)]+[(34,10),(34,11)]+[(x,11) for x in range(26,34)]
assert all(g[y][x] in '.+,' for x,y in ROUTE), [(x,y,g[y][x]) for x,y in ROUTE if g[y][x] not in '.+,']   # NE tower chest: Key to the Sanctum (kept)
open('map_berachah_village_varied_v2.txt','w').write('\n'.join(''.join(r) for r in g)+'\n')
# --- reachability ---
walk=set('.+<>{_^@AMSvbgCV12345678c,:hr~=fo')
block=set('fo{c')  # features you stand next to, not necessarily on
s=(4,17); seen={s}; q=deque([s])
while q:
    x,y=q.popleft()
    for dx in(-1,0,1):
        for dy in(-1,0,1):
            n=(x+dx,y+dy)
            if not(0<=n[1]<H and 0<=n[0]<W) or n in seen: continue
            c=g[n[1]][n[0]]
            if c not in walk: continue
            if dx and dy and (g[y][x]=='+' or c=='+'): continue
            seen.add(n); q.append(n)
bad=[(x,y,g[y][x]) for y in range(H) for x in range(W) if g[y][x] in walk and (x,y) not in seen]
print('unreachable:',bad)
for k in '12345678cC<>MEA@S':
    pts=[(x,y) for y in range(H) for x in range(W) if g[y][x]==k]
    print(k,pts, all(p in seen for p in pts))
print('elder (45,12):',g[12][45],(45,12) in seen,'exit (34,11):',g[11][34],(34,11) in seen)
# --- image ---
C=24; M=60; T=95
img=Image.new('RGB',(M+W*C+30,T+H*C+470),'white'); d=ImageDraw.Draw(img)
F=lambda s:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf',s)
d.text((M,12),'Valley of Berachah - Proposed Layout (varied village V2, draft)',fill='black',font=F(30))
d.text((M,55),'PROPOSAL ONLY - not implemented. Entire level fully lit. Village zone x16-33, y1-19 (purple outline).',fill='#b00000',font=F(16))
col={'-':'#555','|':'#555','T':'#2e8b3a','}':'#4f8fd8','+':'#a0522d','.':'#fff6d8',',':'#bfe8a0',
 'h':'#7fcf7f','~':'#8b6b3d',':':'#f2d7e8','=':'#d8a860','r':'#c7e6ff'}
glyph={'h':'h','~':'~',':':'','=':'=','r':'r'}
lab={'V':'#7b3fa0','@':'#e07b00','A':'#c9a400','M':'#ffd700','S':'#0a7d7d','C':'#d40000','_':'#999','{':'#4f8fd8',
 '<':'#000','>':'#000','^':'#c000c0','v':'#bfe3e3','b':'#bfe3e3','g':'#bfe3e3','o':'#e05a00','f':'#333','c':'#d40000'}
for d_ in '1234567': lab[d_]='#7b3fa0'
lab['8']='#1f8f4f'
for y in range(H):
  for x in range(W):
    c=g[y][x]; X,Y=M+x*C,T+y*C
    if c in col:
        d.rectangle((X,Y,X+C-1,Y+C-1),fill=col[c])
        if c in glyph and glyph[c]: d.text((X+6,Y+3),glyph[c],fill='#333',font=F(14))
    else:
        d.rectangle((X,Y,X+C-1,Y+C-1),fill='#fff6d8')
        if c in 'cfo': d.rectangle((X+2,Y+2,X+C-3,Y+C-3),fill=lab[c])
        else: d.ellipse((X+1,Y+1,X+C-2,Y+C-2),fill=lab[c])
        d.text((X+6,Y+3),c,fill='black' if c in 'vbgM' else 'white',font=F(16))
X,Y=M+45*C,T+12*C; d.ellipse((X+1,Y+1,X+C-2,Y+C-2),fill='#1f5fbf'); d.text((X+6,Y+3),'E',fill='white',font=F(16))
for x in range(0,W,5): d.text((M+x*C+3,T-18),str(x),fill='#444',font=F(12))
for y in range(H): d.text((15,T+y*C+5),str(y),fill='#444',font=F(12))
for x,y in ROUTE: d.rectangle((M+x*C+8,T+y*C+8,M+x*C+C-9,T+y*C+C-9),fill='#ff3fa0')
d.rectangle((M+16*C-2,T+C-2,M+34*C+1,T+20*C+1),outline='#7b3fa0',width=3)
d.rectangle((M+71*C,T+3*C,M+76*C,T+8*C),outline='#d40000',width=4)
yy=T+H*C+18
L=["VILLAGE ROLES (NPC digit = position):",
"1 Baker (18,2) - bakery, outdoor ovens o (22,2)(22,3)     2 Blacksmith (28,2) - forge f (31,2), anvils f (27,5)(31,5)",
"3 Priest (18,8) - restores full Power for a fee; herb garden h x16-19,y12-13     4 Tailor (31,14) - courtyard : y16",
"5 Farmer (18,16) - vegetable beds ~ x16-20,y18-19     6 Carpenter (25,15) - L-shaped home, timber yard = x25-27,y18-19",
"7 Scribe (31,18) - reading garden benches r (26,17)(27,17)     , village green x22-26,y7-12, well { (24,9)",
"8 STEWARD (30,8) in PLAYER'S HOME (x28-33,y6-10, door (28,8)); chests c (32,7)(32,9). Intent: contents persist (not implemented)",
"C (73,5) NE tower chest: Key to the Sanctum (kept)   E (45,12) town elder   M (72,10) Michael   _ (69,10) altar to the LORD",
"@ children   A angels   S shopkeepers   v/b/g verse/book/general shops   < (4,17) arrival   > (69,15) down stair   ^ (7,3)",
"PINK DOTS = clear route: court (69,10) > doors (64,10)(50,10)(44,10) > bridge > gate (41,10) > ruins y10 > (34,10-11) > lane y11 > green",
"Unchanged outside x16-33: portal room, trail, arrival, ruins, hedge, moat, bridge, field gate (41,10), fortress walls/doors"]
for i,l in enumerate(L): d.text((M,yy+i*30),l,fill='black',font=F(16))
img.save('berachah_village_varied_v2.png'); print(img.size)
