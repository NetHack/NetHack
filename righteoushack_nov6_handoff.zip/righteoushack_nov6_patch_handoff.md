# RighteousHack - Nov 6, 2026 Patch Handoff Spec (13-item batch)

STATUS: NOTHING IN THIS BATCH IS IMPLEMENTED. No code was written. This is the full spec for the next bot.

## 0. Project and delivery
- Repo: https://github.com/jonK1984/RighteousHack, development branch `righteoushack-0.1`.
- Jon's workstation copy: `C:\CODE\RighteousHack`. READ-ONLY unless Jon gives explicit permission to write.
- Do NOT use Cursor. Do the work in your own sandbox and give Jon a downloadable patch (e.g. `git format-patch` series plus one combined `.mbox`, applied with `git am`; undo with `git am --abort`), with a short README of PowerShell apply commands.
- Current remote/local HEAD is UNKNOWN. Fetch the current branch and base on it. Do not assume it matches the old patch base.
- Previous, COMPLETED patch (do not confuse with this batch): `/workspace/rh_pr11_patch/pr11_batch.mbox`, based on `3bd25ab6d` (the PR #11 Hinnom/Berachah batch). Preserve all of its changes and everything else already in the repo.

## 1. Repo standards (mandatory)
- Changes go through a PR only. Jon merges it himself.
- Player-visible text must be ASCII only. Do not use em dashes.
- Bible quotes must be exact KJV.
- Nothing blasphemous, occult, or political. Evil may allude to evil, such as child sacrifice, but evil never wins over good.
- Say "prophet mode", never "wizard mode".
- Jon approves all new player-visible text. Mark anything unapproved with a `PLACEHOLDER` comment in the code.
- Keep changes minimal and scoped. Diagnose first, then implement exactly this spec. Don't change behavior anywhere else.
- Update `VERSION_CHANGES.txt` (newest first) and `RIGHTEOUSHACK_CHANGES.md` in the existing style.
- Jon dictates, so check for misheard words: "Mullet"/"Molech" = Moloch, "lepers" = levers, "raise the altar" = raze, "profit mode" = prophet mode.

Approval legend: **[APPROVED]** = Jon approved it explicitly. **[REQUIREMENT]** = firm behavior Jon asked for. **[PROPOSED]** = an assistant draft or suggestion Jon hasn't individually approved, so keep it as PLACEHOLDER. **[CONFIRM]** = wording is ambiguous, so confirm with Jon.

## 2. The 13 items

### 1. Greed trial completion
- [APPROVED exact text] Blackout screen on completion:
```
Your trial is complete. The grip of greed is broken.

Your items appear directly in front of you. Step forward to reclaim them.
```
- [REQUIREMENT] Move the completion message/engraving off the square where the items appear, so it doesn't sit on the item square.

### 2. Rod of Frozen Powers
- [REQUIREMENT] Halve the animation duration only. Effects, damage, and range stay unchanged.

### 3. Cloak titles (Hinnom fortress, while the hero wears the High Priest of Moloch's cloak)
- [REQUIREMENT] Cloaked fortress guards address the hero as "High Priest".
- [REQUIREMENT] Every other "Your Holiness" in those lines becomes "Your Dread Eminence".

### 4. Far-look names
- [REQUIREMENT] The children in Moloch's fortress far-look as "scared child".
- [REQUIREMENT] The Berachah elder far-looks as "town elder", not "prisoner".

### 5. Sword of the Spirit disarm protection
- [REQUIREMENT] It resists being yanked or disarmed (bullwhip, monster disarm, and similar) and stays in hand. Other weapons are unchanged.

### 6. Michael's staged pre-village random lines
- [REQUIREMENT] Michael gets staged random #chat lines for each stage before the village exists.
- [PROPOSED] Earlier in the chat the assistant drafted the full exact lines. Jon's reply was "pretty good, let's get cooking". That is general approval, not explicit approval of each line. [CONFIRM] the final wording. Keep them PLACEHOLDER until Jon confirms.
Stage A: force field down, Moloch alive:
```
Huzzah! The field is broken! Forward, and let us put an end to Moloch!
Take heart! His walls could not save him, and neither shall his throne. To battle!
For the LORD and for the children! Stand with me, and let us finish this!
```
Stage B: Moloch dead, altar still standing:
```
Moloch is fallen, but his altar remains. Raze that seat of evil, that its fires may never burn again!
The battle is won, but our work is not yet finished. Break his altar, and let this place be cleansed!
```
Stage C: Moloch dead, altar razed, before the village appears:
```
Well fought! Moloch is fallen, his altar lies in ruin, and the children are free. You have served the LORD faithfully this day.
Rejoice! The fires are quenched, and this place shall know the cries of children no more. Go to them now, and let them see their deliverer.
You stood firm in the hour of trial. Look upon these broken walls and remember: evil shall not have the final word.
```

### 7. Bread of Berachah
- [REQUIREMENT] Three loaves are given once, at the village welcome screen, when bread is pressed into the hero's hand. Each loaf has the same nutrition as a lembas wafer.
- [APPROVED exact description] `A freshly baked loaf, given in gratitude by the people of Berachah.`

### 8. Hinnom survival and battle
- [REQUIREMENT, firm] Michael must survive the fight. Moloch must still be alive when the hero reaches him, so the hero gets a couple of hits in.
- [PROPOSED mechanism, not firm] Floor Moloch's HP at 25% until the hero engages, and/or a two-hit allowance. The implementer may choose the mechanism, but it must meet the firm requirement above. Moloch's stats stay unchanged.

### 9. Valley of Berachah lighting
- [REQUIREMENT] The entire Valley of Berachah is fully lit with no dark squares. Hinnom's lighting is unchanged.

### 10. Varied central village with eight roles
- [REQUIREMENT] Houses must not be identical cookie-cutter boxes. Use distinct shapes, yards, and arrangements around a village green. Each house has a villager with a specific job. Services are offered via #chat, not shop mechanics. Make it "a really sweet town".
- [REQUIREMENT] Priest: lives in a small home beside an herb garden (this replaces the former healer). Via #chat, for a fee, he restores the Power meter completely. He is not a healer and doesn't treat wounds.
- [REQUIREMENT] Steward: replaces the innkeeper. The steward looks after a larger welcoming home (with a common room) that the village gifts to the player. It holds two initially empty chests for permanent storage. Their contents must ABSOLUTELY persist across leaving and returning, saving and loading, and revisits, and must NEVER be overwritten, reset, or regenerated. The steward's #chat lines are funny, about caring for the home.
- [REQUIREMENT] Carpenter: gives a staff gift, and the Staff of Wonders becomes +2 (details in the roster below).
- [SUGGESTED, broadly accepted] Baker: sells another Bread of Berachah loaf for 10 gold. All other fees are TBD, so confirm them with Jon.
- Eight-role roster [BROADLY APPROVED by Jon ("pretty good, let's get cooking"), including his explicit substitutions of priest for healer and steward for innkeeper]:
  1. Baker: a cottage with an outdoor oven. Sells an additional Bread of Berachah for about 10 gold.
  2. Blacksmith: a broad forge with a fenced workyard, at the village edge. Repairs weapon erosion for a fee. No enchanting.
  3. Priest (instead of the healer): a small home with an herb garden. Refills Power completely for a fee. Does not restore HP.
  4. Tailor: a narrow house with a courtyard. Repairs erosion on cloth armor and cloaks for a fee.
  5. Farmer: a farmhouse with vegetable beds (crops). Gives a one-time gift of fresh food.
  6. Carpenter: an L-shaped house with a timber yard. Gives a one-time wooden staff gift and offers to set a carried Staff of Wonders' current enchantment to +2. [PROPOSED] The one-time safeguard is the assistant's interpretation.
  7. Scribe: a quiet house with a reading garden. Gives useful random advice about what lies ahead.
  8. Steward (player home, instead of the innkeeper): see the steward requirement above.
- Layout: a clear village green with winding paths. The baker sits near the green, the smith at the edge, and the farmer by his crops. Houses are varied, not uniform.
- Fees other than the baker's are TBD and need Jon's confirmation. Service and gift #chat wording other than the lines below was not drafted, so mark it PLACEHOLDER.
- Villager gratitude lines [PROPOSED], random:
```
You saved our children and our home. There will always be a place for you here.
We once feared every footstep outside our doors. Now we open them to welcome you.
My family is together again because you came. Thank you.
These houses stood in darkness. Now there is bread baking and children laughing.
May the LORD bless you for what you have done for us.
Stay awhile, friend. Tonight, you need not fight for anyone. Rest among us.
```
- Steward lines [PROPOSED], random:
```
Welcome home! I have dusted everything except the things that looked liable to bite.
Your belongings are exactly where you left them. I considered organizing them, then thought better of it.
The roof is sound, the floor is swept, and no devils have applied for tenancy.
I have prepared your usual chair. Sitting in it remains entirely your responsibility.
```
- Existing approved text stays: 6 angel victory lines, the one-time welcome screen, and 8 children's thank-you lines. The town elder's 4 lines were PLACEHOLDER as of Nov 4.

### 11. Key to the Sanctum, two locations
- [APPROVED] The key is in two places: Moloch drops one, and a second copy is in a chest in the NE tower room. Jon explicitly approved both locations.
- Coordinate (73,5) comes from the assistant's map preview and is a proposed position, not one Jon specified.

### 12. Michael's random greetings in Berachah
- [REQUIREMENT] In the Valley of Berachah, Michael gives random greeting lines via #chat. [PROPOSED] text. Keep it PLACEHOLDER until approved:
```
Welcome back, friend! Moloch is fallen, the children are safe, and Berachah is home again. Thanks be to the LORD!
Rejoice with us! Where fire and fear once ruled, there is bread and laughter. The LORD has done great things, and we are grateful you stood with us.
Hail, champion of Berachah! Moloch's reign is ended and these families are whole once more. Give thanks to the LORD, and rest here among friends.
```

### 13. Power levers while flying, levitating, or mounted
- Current behavior: stepping on a lever, confirming, and throwing it works on foot. Bug: a flying hero bypasses the lever, and on a flying mount Jon had to dismount to use it.
- [REQUIREMENT] Stepping over a force-field POWER_LEVER while flying, levitating, or riding a flying mount must let the hero use the lever without dismounting.
- [REQUIREMENT] This applies ONLY to POWER_LEVER. All regular trap behavior stays identical.
- Prior approved lever rule (keep it): levers toggle every time, with no "You escape" roll and no "Really step onto" prompt.

## 3. Village map
- PRIMARY (AUTHORITATIVE) MAP: V2 at `/workspace/moloch-level/map_berachah_village_varied_v2.txt`, image `berachah_village_varied_v2.png`, generator `build_berachah_village_varied_v2.py` (all in the zip). STATUS: [PROPOSED DRAFT]. Jon called the V1 varied layout "almost perfect". His one complaint was that the path through the castle courtyard was blocked. V2 fixes only the route.
- Base map: `map_berachah.txt`. Coordinates are (x,y): x = column from 0, y = row from 0.
- Required clear route (V2): Michael's court (68,10) > door (64,10) > hall x51-63,y10 > door (50,10) > gatehouse x45-49,y10 > gate door (44,10) > bridge (43,10),(42,10) > field gate (41,10) > ruins x35-40,y10 > village gateway (34,10)/(34,11) > lane x27-33,y11 > village green x22-26,y7-12. No fixed NPC, chest, fountain, tree or furniture may be placed on these squares. The generator asserts this.
- [REQUIREMENT] V2 changes from V1:
  - The town elder moves from the bridge (43,10) to the gatehouse (45,12). `berachah.lua` currently places him at x=43, y=10; change this to x=45, y=12.
  - The gatehouse angel moves from (46,10) to (46,8). The hall angel moves from (57,10) to Michael's court (71,9).
  - Wall (34,10) becomes floor, making a 2-wide gateway at (34,10)-(34,11).
  - The player home shifts up one row to x28-33,y6-10. Its door is (28,8), the steward is at (30,8), and its chests are at (32,7) and (32,9). Row y11, x28-33, is now an open lane.
  - The blacksmith's anvils move from (27,6),(31,6) to (27,5),(31,5).
- Unchanged from V1: all other roles and coordinates. Baker (18,2), ovens (22,2-3). Blacksmith (28,2), forge (31,2). Priest (18,8), herbs x16-19,y12-13. Tailor (31,14), courtyard x30-33,y16. Farmer (18,16), beds x16-20,y18-19. Carpenter (25,15), L-shaped, timber yard x25-27,y18-19. Scribe (31,18), benches (26,17),(27,17). Green x22-26,y7-12, optional well (24,9). NE key chest (73,5). Michael (72,10), altar (69,10), children, shops, stairs (4,17)/(69,15), and the angels at the field gate (40,9),(40,11) and in the court (73,8),(73,12).
- Validation: the V2 generator reaches every walkable square from `<` (4,17), including all NPCs, doors, both player chests, the key chest and both stairs.
- Player home storage chests: the intent is that their contents persist. This is not implemented.

V2 map (verbatim, PRIMARY, AUTHORITATIVE):
```
-------------------------------------------------------------------------------
|T...........T|.-----.....-------.||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
|.............|.|.1.+.o...|.2..f|.-|....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|..T...^...T..+.|...|.o...|.....|.||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|.-----.....---+---.|--+---T}|...|-----------------------|...|}T|
|.............|............f...f..|....|.T}|...|vvvvvv|bbbbbb|T.T.T.T.T|.C.|}T|
|T...........T|.-----.......------|..TT|.T}|...|Svvvvv|bbbbbS|.........|...|}T|
-------+-------.|...|.,,,,,.|...c||..{...T}--+--+-----------+------+-----+--}T|
|T......TTTTTT|.|.3.+.,,,,,.+.8..||.T---.T}}|.A...|..|..|..|....|.@.@.@..A|}}T|
|T.TTTTTTTTTTT|.|...|.,,{,,.|...c||.....AT}}|.....|-+--+--+--+--|......A..|}}T|
|T...........T|.|...|.,,,,,.------.......+..+.....+.............+...._..M.|}}T|
|TTTTTTTTTTT.T|.-----.,,,,,.............AT}}|.....|--+------+---|.........|}}T|
|TTTTTT......T|.hhhh..,,,,,.......|--|...T}}|.....|.............|.@.@.@..A|}}T|
-------+-------.hhhh..........----|..|.T.T}--+-----+------+---------+----+--}T|
|T...........T|.......|-----..|4.|-.T.T..T}|...|gggSgg|T......T|.......|...|}T|
|.............|.--+--.|..6.+..-+--|......T}|...|gggggg|T..{...T|.....>.|...|}T|
|.............|.|.5.|.|.|---..::::|---+--T}|...|-----------------------|...|}T|
|...<.........|.-----.|.|.rr.-----||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|.~~~~~.---===.+.7.|||....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|T...........T|.~~~~~....===.-----||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
-------------------------------------------------------------------------------
```

- HISTORICAL (superseded by V2): the V1 varied map, files `map_berachah_village_varied.txt` / `berachah_village_varied.png` / `build_berachah_village_varied.py`. It had the player home at x28-33,y7-11 (door (28,9), steward (30,9), chests (32,8),(32,10)) and the elder on the bridge. Its coordinate list: baker (18,2); blacksmith (28,2); priest (18,8); tailor (31,14); farmer (18,16); carpenter (25,15); scribe (31,18); steward (30,9).

Revised varied map (verbatim, HISTORICAL V1, superseded):
```
-------------------------------------------------------------------------------
|T...........T|.-----.....-------.||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
|.............|.|.1.+.o...|.2..f|.-|....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|..T...^...T..+.|...|.o...|.....|.||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|.-----.....---+---.|--+---T}|...|-----------------------|...|}T|
|.............|...................|....|.T}|...|vvvvvv|bbbbbb|T.T.T.T.T|.C.|}T|
|T...........T|.-----......f...f..|..TT|.T}|...|Svvvvv|bbbbbS|.........|...|}T|
-------+-------.|...|.,,,,,.------|..{...T}--+--+-----------+------+-----+--}T|
|T......TTTTTT|.|.3.+.,,,,,.|...c||.T---.T}}|.....|..|..|..|....|.@.@.@..A|}}T|
|T.TTTTTTTTTTT|.|...|.,,{,,.+.8..||.....AT}}|.....|-+--+--+--+--|.........|}}T|
|T...........T|.|...|.,,,,,.|...c||......+..+.A...+......A......+...._..M.|}}T|
|TTTTTTTTTTT.T|.-----.,,,,,.------......AT}}|.....|--+------+---|.........|}}T|
|TTTTTT......T|.hhhh..,,,,,.......|--|...T}}|.....|.............|.@.@.@..A|}}T|
-------+-------.hhhh..........----|..|.T.T}--+-----+------+---------+----+--}T|
|T...........T|.......|-----..|4.|-.T.T..T}|...|gggSgg|T......T|.......|...|}T|
|.............|.--+--.|..6.+..-+--|......T}|...|gggggg|T..{...T|.....>.|...|}T|
|.............|.|.5.|.|.|---..::::|---+--T}|...|-----------------------|...|}T|
|...<.........|.-----.|.|.rr.-----||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|.~~~~~.---===.+.7.|||....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|T...........T|.~~~~~....===.-----||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
-------------------------------------------------------------------------------
```


- HISTORICAL REFERENCE ONLY: the original preview, `berachah_village_proposal.png` / `build_berachah_village_proposal.py`. Jon rejected its uniform houses.
- The original preview below is the geometric baseline for everything outside the village zone.
- Coordinates: (x,y), x = column from 0 (left), y = row from 0 (top). The level never flips.
- Original preview legend (from its generator): purple zone x15-33 = the central maze replaced by the village. V = villager. C (73,5) = NE tower chest with the 2nd Key to the Sanctum. E (43,10) = town elder (on the bridge; not drawn in the ASCII). M (72,10) = Michael's court. _ (69,10) = altar to the LORD. @ = six children. A = angels. S = shopkeepers. v (48-53,5-6) = verse shop. b (55-60,5-6) = prophetic book shop. g (48-53,14-15) = general store. < (4,17) = arrival stair. > (69,15) = down stair. ^ (7,3) = portal spot. { = fountains of living water. T = trees. } = still waters. + = doors. Field gate (41,10) and bridge (42-43,10) unchanged. West portal room, trail, arrival room, ruins, hedge ring, moat, and fortress walls/doors are unchanged.

Original preview (verbatim, HISTORICAL, superseded):
```
-------------------------------------------------------------------------------
|T...........T|...-----...-----...||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
|.............|...|...+...+...|...-|....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|..T...^...T..+...|.V.|...|.V.|...||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|...-----...-----...|--+---T}|...|-----------------------|...|}T|
|.............|.........V......T..|....|.T}|...|vvvvvv|bbbbbb|T.T.T.T.T|.C.|}T|
|T...........T|...-----...-----...|..TT|.T}|...|Svvvvv|bbbbbS|.........|...|}T|
-------+-------...|...+...+...|...|..{...T}--+--+-----------+------+-----+--}T|
|T......TTTTTT|...|.V.|...|.V.|.V.|.T---.T}}|.....|..|..|..|....|.@.@.@..A|}}T|
|T.TTTTTTTTTTT|...-----...-----...|.....AT}}|.....|-+--+--+--+--|.........|}}T|
|T...........T|..V................|......+..+.A...+......A......+...._..M.|}}T|
|TTTTTTTTTTT.T|...-----...-----.........AT}}|.....|--+------+---|.........|}}T|
|TTTTTT......T|...|...+...+...|...|--|...T}}|.....|.............|.@.@.@..A|}}T|
-------+-------...|.V.|...|.V.|...|..|.T.T}--+-----+------+---------+----+--}T|
|T...........T|...-----...-----T..-.T.T..T}|...|gggSgg|T......T|.......|...|}T|
|.............|.........V.........|......T}|...|gggggg|T..{...T|.....>.|...|}T|
|.............|...-----...-----...|---+--T}|...|-----------------------|...|}T|
|...<.........|...|...+...+...|...||....|T}-----}}}}}}}}}}}}}}}}}}}}}}}-----}T|
|.............|...|.V.|...|.V.|...||....|T}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}T|
|T...........T|...-----...-----...||....|TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT|
-------------------------------------------------------------------------------
```

## 4. Acceptance and regression checklist
- [ ] The patch applies cleanly with `git am` on the current branch head. Build passes.
- [ ] Greed: the exact blackout text shows, the items appear in front of the hero, and the message is not on the item square.
- [ ] Rod animation is half as long. Its effects are unchanged.
- [ ] Cloaked titles: guards say "High Priest", and no "Your Holiness" remains in the cloaked lines.
- [ ] Far-look: "scared child" (fortress) and "town elder" (Berachah).
- [ ] The Sword of the Spirit can't be disarmed. Other weapons can still be disarmed as before.
- [ ] Michael's staged lines and Berachah greetings are random and PLACEHOLDER-tagged until approved.
- [ ] Bread: 3 loaves given once, lembas nutrition, exact description. The baker sells a loaf for 10 gold.
- [ ] Michael survives. Moloch is alive when the hero arrives, and the hero lands hits.
- [ ] No dark squares in Berachah. Hinnom's lighting is unchanged.
- [ ] Houses are varied, with all 8 roles. The priest restores Power fully for a fee. The carpenter's +2 Staff of Wonders works.
- [ ] Steward chests: put items in, leave the level, return, save, quit, reload, and revisit several times. The items are still there every time and are never reset.
- [ ] The key is in both locations.
- [ ] The lever works while flying, levitating, and on a flying mount. Normal traps behave exactly as before.
- [ ] No monster spawns in Berachah, no mimics in its shops, and no level flip. Earlier PR #11 behavior is intact.
- [ ] ASCII only, exact KJV, no em dash, "prophet mode", and both changelogs updated.
- [ ] Report each commit hash with a one-line summary, the build and test results (real results only), and any deviations.
